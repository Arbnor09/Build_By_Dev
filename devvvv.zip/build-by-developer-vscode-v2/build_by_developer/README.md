# Build By Developer — Web Project (VS Code Ready)

Struktura e projektit është ndarë në fajlla të pastër dhe modularë për editim të lehtë në **Visual Studio Code**:

```text
build_by_developer_vscode/
├── index.html             # Struktura kryesore HTML (Home, About-Us, Prices, Contact-Us)
├── css/
│   └── style.css          # Stilizimet e personalizuara, animacionet dhe efektet glassmorphism
├── js/
│   ├── translations.js    # Përkthimet e plota në 3 gjuhë (SQ, EN, DE)
│   ├── pricing-data.js    # Paketat dhe çmimet për Web, App dhe Marketing Digjital
│   └── app.js             # Logjika e navigimit, Dark/Light mode, dhe dërgimi i email-it
├── assets/                # Vendosni këtu fotot tuaja:
│   ├── logo.jpeg          # Logoja e kompanisë (WhatsApp Image 2026-11-13 at 22.55.11.jpeg)
│   ├── elvedin.jpeg       # Foto e profilit të Elvedin Rexha
│   ├── arbnor.jpeg        # Foto e profilit të Arbnor Rexhepi
│   └── meriton.jpeg       # Foto e profilit të Meriton Berisha
└── README.md              # Udhëzime përdorimi
```
