/* ==========================================================================
   Build By Developer - Pricing Categories & 3 Packages per Category
   ========================================================================== */

const pricingData = {
    web: [
        {
            tier: "Web Starter",
            price: "€290",
            featured: false,
            desc: {
                sq: "Ideale për biznese të reja dhe prezantim profesional online.",
                en: "Ideal for startups and a clean professional online presence.",
                de: "Ideal für Start-ups und eine professionelle Online-Präsenz."
            },
            features: {
                sq: ["Deri në 5 faqe moderne & responsive", "Dizajn i përshtatur për Mobile & Desktop", "Formular kontakti & integrim WhatsApp", "Optimizim bazik SEO & SSL falas", "1 muaj mirëmbajtje teknike falas"],
                en: ["Up to 5 modern & responsive pages", "Tailored Mobile & Desktop layout", "Contact form & WhatsApp integration", "Basic SEO setup & free SSL", "1 month free technical maintenance"],
                de: ["Bis zu 5 moderne & responsive Seiten", "Optimiertes Mobile- & Desktop-Layout", "Kontaktformular & WhatsApp-Integration", "Basis-SEO & kostenloses SSL", "1 Monat kostenlose Wartung"]
            }
        },
        {
            tier: "Web Business Pro",
            price: "€590",
            featured: true,
            desc: {
                sq: "Zgjidhja më e kërkuar për kompani në rritje dhe brende.",
                en: "Most popular choice for growing companies and established brands.",
                de: "Beliebteste Wahl für wachsende Unternehmen und etablierte Marken."
            },
            features: {
                sq: ["Deri në 12 faqe të personalizuara", "Suport multi-gjuhësh (SQ / EN / DE)", "Panel administrimi (CMS) për editime", "Optimizim i avancuar SEO & shpejtësi 95+", "3 muaj suport teknik prioritar"],
                en: ["Up to 12 custom-designed pages", "Multi-language support (SQ / EN / DE)", "Admin CMS panel for easy content edits", "Advanced SEO & 95+ speed optimization", "3 months priority technical support"],
                de: ["Bis zu 12 individuelle Seiten", "Mehrsprachigkeit (SQ / EN / DE)", "Admin-CMS-Panel für Inhaltsverwaltung", "Erweitertes SEO & 95+ Speed-Score", "3 Monate Prioritäts-Support"]
            }
        },
        {
            tier: "E-Commerce Store",
            price: "€990",
            featured: false,
            desc: {
                sq: "Dyqan online i kompletuar për shitje 24/7 me menaxhim stoku.",
                en: "Complete online store for 24/7 sales with full inventory control.",
                de: "Kompletter Online-Shop für 24/7-Verkauf mit Lagerverwaltung."
            },
            features: {
                sq: ["Katalog produktesh & kategori pa limit", "Pagesa me kartë & Cash on Delivery", "Menaxhim porosish, zbritjesh & faturash", "Dizajn i optimizuar për konvertim", "6 muaj suport & siguri e avancuar"],
                en: ["Unlimited product catalog & categories", "Card payments & Cash on Delivery", "Order, coupon & invoice management", "High-conversion checkout experience", "6 months support & advanced security"],
                de: ["Unbegrenzter Produktkatalog", "Kartenzahlung & Nachnahme", "Bestell-, Rabatt- & Rechnungsverwaltung", "Konversionsoptimierter Checkout", "6 Monate Support & hohe Sicherheit"]
            }
        }
    ],
    app: [
        {
            tier: "App Starter MVP",
            price: "€990",
            featured: false,
            desc: {
                sq: "Versioni i parë funksional i aplikacionit tuaj për Android & iOS.",
                en: "First functional MVP version of your app for Android & iOS.",
                de: "Erste funktionale MVP-Version Ihrer App für Android & iOS."
            },
            features: {
                sq: ["Aplikacion Cross-Platform (iOS & Android)", "Regjistrim & profil përdoruesi", "Dizajn modern UI/UX i përshtatur", "Panel bazik për menaxhimin e të dhënave", "2 muaj suport pas publikimit"],
                en: ["Cross-Platform App (iOS & Android)", "User authentication & profiles", "Modern tailored UI/UX design", "Basic admin dashboard for data", "2 months post-launch support"],
                de: ["Cross-Platform-App (iOS & Android)", "Benutzer-Login & Profile", "Modernes UI/UX-Design", "Basis-Admin-Dashboard", "2 Monate Post-Launch-Support"]
            }
        },
        {
            tier: "Cross-Platform Pro",
            price: "€1,890",
            featured: true,
            desc: {
                sq: "Aplikacion i plotë biznesi me njoftime push dhe pagesa online.",
                en: "Full-featured business app with push notifications and payments.",
                de: "Vollständige Business-App mit Push-Mitteilungen und Zahlungen."
            },
            features: {
                sq: ["iOS & Android me performancë të lartë", "Push Notifications & sistem rezervimesh", "Integrim pagesash & API të jashtme", "Panel i avancuar administrimi & analitikë", "Publikim në App Store & Google Play"],
                en: ["High-performance iOS & Android builds", "Push Notifications & booking system", "Payment gateway & external APIs", "Advanced admin dashboard & analytics", "App Store & Google Play submission"],
                de: ["Leistungsstarke iOS- & Android-Apps", "Push-Benachrichtigungen & Buchungen", "Zahlungs-Gateway & externe APIs", "Erweitertes Admin-Dashboard", "App Store & Google Play Veröffentlichung"]
            }
        },
        {
            tier: "Enterprise Custom App",
            price: "€3,490+",
            featured: false,
            desc: {
                sq: "Sistem i personalizuar me arkitekturë cloud dhe shkallëzueshmëri.",
                en: "Bespoke application with scalable cloud backend architecture.",
                de: "Maßgeschneiderte Anwendung mit skalierbarer Cloud-Architektur."
            },
            features: {
                sq: ["Arkitekturë e dedikuar Cloud & Backend", "Role të shumta përdoruesish & siguri e lartë", "Sinkronizim në kohë reale (Live Tracking/Chat)", "Raporte të avancuara & eksport të dhënash", "6 muaj mirëmbajtje & SLA i dedikuar"],
                en: ["Dedicated Cloud & Backend architecture", "Multi-role permissions & enterprise security", "Real-time sync (Live Tracking / Chat)", "Advanced reporting & data exports", "6 months dedicated maintenance & SLA"],
                de: ["Dedizierte Cloud- & Backend-Architektur", "Mehrstufige Benutzerrollen & Sicherheit", "Echtzeit-Synchronisation", "Erweiterte Berichte & Datenexport", "6 Monate Wartung & SLA"]
            }
        }
    ],
    marketing: [
        {
            tier: "Social Start",
            price: "€250/muaj",
            featured: false,
            desc: {
                sq: "Menaxhim profesional i rrjeteve sociale për rritje organike.",
                en: "Professional social media management for steady brand presence.",
                de: "Professionelles Social-Media-Management für Markenpräsenz."
            },
            features: {
                sq: ["Menaxhim Instagram & Facebook", "12 postime kreative + Reels në muaj", "Dizajn grafik i personalizuar për brendin", "Copywriting & Hashtag strategji", "Raport mujor i performancës"],
                en: ["Instagram & Facebook management", "12 creative posts + Reels per month", "Custom branded graphic design", "Copywriting & hashtag strategy", "Monthly performance report"],
                de: ["Instagram- & Facebook-Management", "12 kreative Beiträge + Reels pro Monat", "Individuelles Grafikdesign", "Copywriting & Hashtag-Strategie", "Monatlicher Performance-Bericht"]
            }
        },
        {
            tier: "Growth Accelerator",
            price: "€490/muaj",
            featured: true,
            desc: {
                sq: "Fushata të targetuara Meta & Google Ads për rritje të shitjeve.",
                en: "Targeted Meta & Google Ads campaigns engineered to scale sales.",
                de: "Zielgerichtete Meta- & Google-Ads-Kampagnen für mehr Umsatz."
            },
            features: {
                sq: ["20 postime + video/Reels profesionale", "Menaxhim & optimizim Meta Ads (FB/IG)", "Fushata Google Search Ads për klientë aktivë", "Targetim i audiencës & Retargeting", "Raportim javor & optimizim ROI"],
                en: ["20 posts + professional Reels/videos", "Meta Ads (FB/IG) campaign management", "Google Search Ads for high-intent leads", "Audience targeting & Retargeting", "Weekly reporting & ROI optimization"],
                de: ["20 Beiträge + professionelle Reels", "Meta Ads (FB/IG) Kampagnenmanagement", "Google Search Ads für aktive Kunden", "Zielgruppen-Targeting & Retargeting", "Wöchentliches Reporting & ROI-Fokus"]
            }
        },
        {
            tier: "Brand Domination 360°",
            price: "€890/muaj",
            featured: false,
            desc: {
                sq: "Strategji e plotë digjitale për dominim të tregut në çdo kanal.",
                en: "Full-funnel digital marketing strategy for total market dominance.",
                de: "Ganzheitliche Digital-Marketing-Strategie für maximale Reichweite."
            },
            features: {
                sq: ["Menaxhim i plotë IG, FB, TikTok & LinkedIn", "30 përmbajtje mujore (Foto, Reels, Video)", "Fushata multi-kanal Meta, Google & TikTok Ads", "SEO mujor për renditje të lartë në Google", "Menaxher i dedikuar & strategji 1-me-1"],
                en: ["Full IG, FB, TikTok & LinkedIn management", "30 monthly assets (Graphics, Reels, Video)", "Multi-channel Meta, Google & TikTok Ads", "Monthly SEO for top Google rankings", "Dedicated account manager & 1-on-1 strategy"],
                de: ["Komplettes IG-, FB-, TikTok- & LinkedIn-Management", "30 Inhalte pro Monat (Grafik, Reels, Video)", "Multi-Channel Meta, Google & TikTok Ads", "Monatliches SEO für Top-Google-Rankings", "Dedizierter Account-Manager"]
            }
        }
    ]
};
