/* ==========================================================================
   Build By Developer - Core Application Logic & UI Controllers (js/app.js)
   ========================================================================== */

// State Management
let currentLang = 'sq';
let currentPage = 'home';
let currentPriceCat = 'web';

// Navigation Function (SPA Section Switcher)
function navigateTo(pageId) {
    currentPage = pageId;
    document.querySelectorAll('.page-section').forEach(sec => {
        sec.classList.add('hidden');
    });
    const activeSection = document.getElementById(`page-${pageId}`);
    if (activeSection) {
        activeSection.classList.remove('hidden');
    }

    // Update active nav link styling
    document.querySelectorAll('.nav-link').forEach(btn => {
        if (btn.dataset.nav === pageId) {
            btn.classList.add('bg-brand-600', 'text-white', 'shadow-sm');
            btn.classList.remove('text-slate-600', 'dark:text-slate-300', 'hover:bg-slate-100', 'dark:hover:bg-slate-900');
        } else {
            btn.classList.remove('bg-brand-600', 'text-white', 'shadow-sm');
            btn.classList.add('text-slate-600', 'dark:text-slate-300', 'hover:bg-slate-100', 'dark:hover:bg-slate-900');
        }
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Mobile Menu Toggle
function toggleMobileMenu() {
    const menu = document.getElementById('mobile-menu');
    menu.classList.toggle('hidden');
}

// Dark / Light Theme Toggle
function toggleTheme() {
    const html = document.documentElement;
    html.classList.toggle('dark');
}

// Multi-Language Switcher (SQ, EN, DE)
function setLanguage(lang) {
    currentLang = lang;
    document.documentElement.lang = lang;

    // Update language buttons UI
    document.querySelectorAll('.lang-btn').forEach(btn => {
        if (btn.dataset.lang === lang) {
            btn.classList.add('bg-brand-600', 'text-white', 'shadow-sm');
            btn.classList.remove('text-slate-600', 'dark:text-slate-400');
        } else {
            btn.classList.remove('bg-brand-600', 'text-white', 'shadow-sm');
            btn.classList.add('text-slate-600', 'dark:text-slate-400');
        }
    });

    // Translate all static elements with data-i18n
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[lang] && translations[lang][key]) {
            el.textContent = translations[lang][key];
        }
    });

    // Re-render pricing cards for the active language
    renderPricingCards();
}

// Pricing Category Tabs Switcher
function setPriceCategory(cat) {
    currentPriceCat = cat;
    document.querySelectorAll('.price-cat-btn').forEach(btn => {
        if (btn.dataset.cat === cat) {
            btn.classList.add('bg-brand-600', 'text-white', 'shadow-md', 'shadow-brand-600/20');
            btn.classList.remove('bg-white', 'dark:bg-slate-900', 'text-slate-700', 'dark:text-slate-300', 'border', 'border-slate-200', 'dark:border-slate-800');
        } else {
            btn.classList.remove('bg-brand-600', 'text-white', 'shadow-md', 'shadow-brand-600/20');
            btn.classList.add('bg-white', 'dark:bg-slate-900', 'text-slate-700', 'dark:text-slate-300', 'border', 'border-slate-200', 'dark:border-slate-800');
        }
    });
    renderPricingCards();
}

// Dynamic Pricing Cards Renderer
function renderPricingCards() {
    const container = document.getElementById('pricing-cards-container');
    const packages = pricingData[currentPriceCat];
    const popularLabel = translations[currentLang].popular_badge;
    const orderLabel = translations[currentLang].order_btn;

    container.innerHTML = packages.map(pkg => `
        <div class="relative p-8 rounded-2xl flex flex-col justify-between transition-all ${
            pkg.featured 
            ? 'bg-slate-900 dark:bg-slate-900 text-white border-2 border-brand-500 shadow-xl shadow-brand-500/15 lg:-translate-y-2' 
            : 'bg-white dark:bg-slate-900/80 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 shadow-sm'
        }">
            ${pkg.featured ? `
                <div class="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3.5 py-1 rounded-full bg-gradient-to-r from-brand-600 to-accent-500 text-white text-xs font-bold uppercase tracking-wider shadow">
                    ${popularLabel}
                </div>
            ` : ''}

            <div>
                <h3 class="font-display text-xl font-bold">${pkg.tier}</h3>
                <p class="text-xs mt-2 ${pkg.featured ? 'text-slate-300' : 'text-slate-500 dark:text-slate-400'}">${pkg.desc[currentLang]}</p>
                <div class="my-6 pb-6 border-b ${pkg.featured ? 'border-slate-800' : 'border-slate-200 dark:border-slate-800'}">
                    <span class="font-display text-4xl font-extrabold">${pkg.price}</span>
                </div>
                <ul class="space-y-3.5 mb-8">
                    ${pkg.features[currentLang].map(feat => `
                        <li class="flex items-start gap-3 text-sm ${pkg.featured ? 'text-slate-200' : 'text-slate-600 dark:text-slate-300'}">
                            <svg class="w-5 h-5 text-accent-400 shrink-0 mt-0.5" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                            </svg>
                            <span>${feat}</span>
                        </li>
                    `).join('')}
                </ul>
            </div>

            <button onclick="selectPackageForContact('${pkg.tier} (${pkg.price})')" class="w-full py-3.5 px-5 rounded-xl font-bold text-sm transition-all ${
                pkg.featured 
                ? 'bg-brand-600 hover:bg-brand-500 text-white shadow-lg shadow-brand-600/30' 
                : 'bg-slate-100 dark:bg-slate-800 hover:bg-brand-600 hover:text-white text-slate-900 dark:text-white'
            }">
                ${orderLabel}
            </button>
        </div>
    `).join('');
}

// Pre-fill Contact Form when user selects a package
function selectPackageForContact(packageInfo) {
    navigateTo('contact');
    const subjectInput = document.getElementById('contact-subject');
    if (subjectInput) {
        subjectInput.value = packageInfo;
    }
}

// Contact Form Submission -> Direct Email to bydevbuild@gmail.com
function handleContactSubmit(e) {
    e.preventDefault();
    const name = document.getElementById('contact-name').value.trim();
    const email = document.getElementById('contact-email').value.trim();
    const subject = document.getElementById('contact-subject').value.trim();
    const message = document.getElementById('contact-message').value.trim();

    const mailSubject = encodeURIComponent(`[Build By Developer] ${subject} - ${name}`);
    const mailBody = encodeURIComponent(
        `Name: ${name}\nEmail: ${email}\nPackage / Service: ${subject}\n\nMessage:\n${message}`
    );

    const feedback = document.getElementById('contact-feedback');
    feedback.textContent = translations[currentLang].form_sent_msg;
    feedback.classList.remove('hidden');

    window.location.href = `mailto:bydevbuild@gmail.com?subject=${mailSubject}&body=${mailBody}`;
}

// Initialize Application on DOM Ready
window.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    setLanguage('sq');
    setPriceCategory('web');
    navigateTo('home');
});
